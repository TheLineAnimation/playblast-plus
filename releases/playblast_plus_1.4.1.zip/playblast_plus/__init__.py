from pathlib import Path
"""
Define a constant for this module location install 
"""
PLAYBLAST_PLUS_MODULE_ROOT = Path(__file__).parent.absolute()